


import org.antlr.v4.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeWalker;

public class Sql {
	public static void main(String[] args) {
		 String str="INSERT INTO C SELECT * FROM A LEFT JOIN B ON ASDAASFDSVFS";
		 str="INSERT INTO direct SELECT userid,name FROM (SELECT sex AS userid,userid AS sex,name AS name FROM A LEFT JOIN C ON SFCEFAWEFVV)  D UNION ALL SELECT userid,name FROM B; ";
		 str="INSERT INTO HJ.SRC_D_BCD_ORACLE (USER_ID,PARTITION_ID )SELECT * FROM ( SELECT SourceQulifier_1.USER_ID AS USER_ID, SourceQulifier_1.PARTITION_ID AS PARTITION_ID FROM HJ.DET_D_BCD_ORACLE SourceQulifier_1 LEFT JOIN HJ.SRC_D_BCD_ORACLE_ISOMERY SourceQulifier_3 ON ( SourceQulifier_1.USER_ID = SourceQulifier_3.DAY_ID ) RIGHT JOIN HJ.SRC_D_BCD1227 SourceQulifier_5 ON ( SourceQulifier_1.USER_ID = SourceQulifier_5.USER_ID ))tableA WHERE USER_ID>10;";
	       sqlLexer lexer=new sqlLexer(new ANTLRInputStream(str));
	       CommonTokenStream tokens =new CommonTokenStream(lexer);
	       sqlParser parser = new sqlParser(tokens);
	       ParseTree tree= parser.prog();
//	       System.out.println(tree.toStringTree(parser));
//	       Mappingvisitor eval = new Mappingvisitor();  
//	       eval.visit(tree);  
	       ParseTreeWalker walker = new  ParseTreeWalker();
	       MappingListener listen =new MappingListener();
	       walker.walk(listen,tree);
	       
	       
	}

}
